<?php
    class person{
        protected $name;
        public $height;
        protected $social_insurance;
        private $pin_no;

        function _construct($person_name){
            $this->name = $person_name;
        }
        public function set_name($new_name){
            $this->name = $new_name;
        }
        function get_name(){
            return $this->name;
        }
        public function set_pin_no($new_pin){
            $this->pin_no = $new_pin;
        }
        function get_pin_no(){
            return $this->pin_no;
        }
    }

    // child class
    class employee extends person{
        // overriding method

        public function set_name($new_name){
            if($new_name == "Alina"){
                $this->name = strtoupper($new_name);
            }
            elseif($new_name == " Ali"){
                $this->name = strtolower($new_name);
            }
            else {
                person :: set_name($new_name);
            }
        }

        function _construct($employee_name){
            $this->set_name($employee_name);
        }
    }

?>