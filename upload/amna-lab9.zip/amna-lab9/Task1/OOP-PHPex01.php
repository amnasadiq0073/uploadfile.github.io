<?php include("mylib.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php
        $kamran = new person("Kamran Malik");
        $fatima = new person("Fatima Rehan");

        $kamran->set_pin_no(1234);
        echo "Kamran's full name : " . $kamran->get_name() . "<BR>";
        echo "Kamran's pin no : " . $kamran->get_pin_no() . "<BR>";
        echo "Fatima's full name : " . $fatima->get_name() . "<BR>";
        
        $kamran = new person("Kamran Malik");
        echo "Kamran's full name : " . $kamran->get_name() . "<BR>";

        $alina = new employee("Alina");
        echo "Over riding parents function : " . $alina->get_name() . "<BR>";

        $ali = new employee("Ali");
        echo "Over riding parents function : " . $ali->get_name() . "<BR>";

        $alina->set_pin_no(4321);
        echo "Alina's pin no : ". $alina->get_pin_no()."<BR>";
    ?>
</body>
</html>
